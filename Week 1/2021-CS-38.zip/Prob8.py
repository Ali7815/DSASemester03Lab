# -*- coding: utf-8 -*-
"""
Created on Fri Sep  9 14:26:45 2022

@author: Digital Zone
"""

import funcs
A=[0,2,4,10,11]
B=[1,8,13,24]
sortedArr=funcs.SortedMerge(A,B)
print(sortedArr)
