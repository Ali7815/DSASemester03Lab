# -*- coding: utf-8 -*-
"""
Created on Fri Sep  9 14:38:23 2022

@author: Digital Zone
"""

import funcs
str=input("Enter String : ")
chk=funcs.PalindromRecursive(str)
print(chk)