# -*- coding: utf-8 -*-
"""
Created on Sat Sep 10 15:08:58 2022

@author: Digital Zone
"""
import funcs
Arr=[10,-1,9,20,-3,-8,22,9,7]
res=funcs.Sort10(Arr)
print(res)