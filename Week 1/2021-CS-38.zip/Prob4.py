# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 22:08:19 2022

@author: Digital Zone
"""
import funcs
X=[3,4,7,8,0,1,23,-2,-5]
array=funcs.Sort4(X)
print(array)
