# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 21:15:18 2022

@author: Digital Zone
"""
import funcs
X=[22,2,1,7,11,13,5,2,9]
x=input("Enter Number To Find Index of It : ")
x=int(x)
Arr1=funcs.SearchA(X,x)
print(Arr1)

